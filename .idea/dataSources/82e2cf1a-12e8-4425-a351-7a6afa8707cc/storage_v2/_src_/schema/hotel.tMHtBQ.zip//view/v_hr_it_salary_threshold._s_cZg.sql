create definer = root@localhost view v_hr_it_salary_threshold as
select `hotel`.`employees`.`id`         AS `id`,
       `hotel`.`employees`.`first_name` AS `first_name`,
       `hotel`.`employees`.`last_name`  AS `last_name`
from `hotel`.`employees`
where ((`hotel`.`employees`.`department_id` = 4) and (`hotel`.`employees`.`salary` >= 1000))
order by `hotel`.`employees`.`id`;

