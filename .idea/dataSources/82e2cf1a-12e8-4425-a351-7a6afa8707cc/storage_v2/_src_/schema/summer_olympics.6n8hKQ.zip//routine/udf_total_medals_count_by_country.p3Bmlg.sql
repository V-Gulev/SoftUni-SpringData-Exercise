create
    definer = root@localhost function udf_total_medals_count_by_country(name varchar(40)) returns int reads sql data
begin
	return(select
		count(dam.medal_id) 
		from countries c
		join athletes a on a.country_id = c.id
		join disciplines_athletes_medals dam on dam.athlete_id = a.id
		where c.name = name);
end;

