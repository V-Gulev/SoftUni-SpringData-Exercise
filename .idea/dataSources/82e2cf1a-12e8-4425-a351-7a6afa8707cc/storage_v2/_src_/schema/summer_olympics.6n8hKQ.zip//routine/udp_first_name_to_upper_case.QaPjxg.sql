create
    definer = root@localhost procedure udp_first_name_to_upper_case(IN letter char) reads sql data
begin
	update athletes
	set first_name = upper(first_name)
	where substring(first_name, -1 ) = letter;
end;

