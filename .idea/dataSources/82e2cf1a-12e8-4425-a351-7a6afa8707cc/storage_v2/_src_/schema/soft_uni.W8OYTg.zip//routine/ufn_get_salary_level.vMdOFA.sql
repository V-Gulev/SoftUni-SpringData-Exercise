create
    definer = root@localhost function ufn_get_salary_level(salary decimal(12, 4)) returns varchar(8) deterministic
begin 
	return case
				when salary < 30000 then 'Low'
                when salary <= 50000 then 'Average'
                else 'High'
			end;
end;

