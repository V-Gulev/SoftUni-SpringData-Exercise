create
    definer = root@localhost procedure usp_get_employees_by_salary_level(IN salary_level varchar(8))
select first_name, last_name
from employees
where ufn_get_salary_level(salary) = salary_level
order by first_name desc, last_name desc;

