create
    definer = root@localhost procedure usp_get_employees_from_town(IN town_name text)
select e.first_name, e.last_name 
    from employees e
    join addresses a on e.address_id = a.address_id
    join towns t on t.town_id = a.town_id
    where t.name = town_name
    order by e.first_name, e.last_name, e.employee_id;

