create definer = root@localhost trigger trg_account_changes
    after update
    on accounts
    for each row
begin
	if OLD.balance != NEW.balance then
		insert into logs
		values (NEW.id, OLD.balance, NEW.balance);
    end if;
end;

