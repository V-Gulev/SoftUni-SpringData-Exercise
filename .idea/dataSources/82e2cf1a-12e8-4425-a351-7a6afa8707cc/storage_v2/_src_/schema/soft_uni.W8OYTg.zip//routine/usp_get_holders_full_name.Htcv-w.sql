create
    definer = root@localhost procedure usp_get_holders_full_name()
select concat(first_name, ' ' , last_name) as full_name
from account_holders
order by full_name, id;

