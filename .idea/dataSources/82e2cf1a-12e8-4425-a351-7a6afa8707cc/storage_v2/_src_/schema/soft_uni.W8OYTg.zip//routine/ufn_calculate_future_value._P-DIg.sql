create
    definer = root@localhost function ufn_calculate_future_value(initial_amount decimal(12, 4),
                                                                 interest_rate double(12, 4),
                                                                 years int) returns decimal(12, 4) deterministic
    return initial_amount * (pow((1 + interest_rate), years));

