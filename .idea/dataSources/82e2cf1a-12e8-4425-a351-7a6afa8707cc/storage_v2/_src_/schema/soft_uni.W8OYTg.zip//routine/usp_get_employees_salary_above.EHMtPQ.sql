create
    definer = root@localhost procedure usp_get_employees_salary_above(IN target_salary decimal(12, 4))
select first_name, last_name
	from employees
	where salary >= target_salary
	order by first_name, last_name, employee_id;

