create
    definer = root@localhost procedure usp_get_towns_starting_with(IN search_string text)
select name town_name
	from towns
	where name like concat(search_string, '%')
    order by town_name;

