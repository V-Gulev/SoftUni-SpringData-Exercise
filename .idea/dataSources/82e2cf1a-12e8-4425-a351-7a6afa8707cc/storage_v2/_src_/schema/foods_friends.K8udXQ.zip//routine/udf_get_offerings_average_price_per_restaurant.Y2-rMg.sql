create
    definer = root@localhost function udf_get_offerings_average_price_per_restaurant(restaurant_name varchar(40)) returns decimal(19, 2)
    deterministic
    reads sql data
begin
	return(select round(avg(o.price), 2)
	from restaurants r
	join offerings o on r.id = o.restaurant_id
	where r.name like restaurant_name
	group by r.id);
end;

