create
    definer = root@localhost function udf_average_price_by_city(name varchar(40)) returns decimal(10, 2) reads sql data
begin
	return (select avg(rc.price_per_day)
	from cities c
	join rental_companies rc on c.id = rc.city_id
	where c.name like name);
end;

