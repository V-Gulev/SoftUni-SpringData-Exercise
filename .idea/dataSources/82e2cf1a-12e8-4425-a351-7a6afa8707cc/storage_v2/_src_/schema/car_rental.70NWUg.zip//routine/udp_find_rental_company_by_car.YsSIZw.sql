create
    definer = root@localhost procedure udp_find_rental_company_by_car(IN brand varchar(20)) reads sql data
begin
	select rc.name, rc.price_per_day
	from rental_companies rc
	join cars c on rc.car_id = c.id
	where c.brand like brand
	order by rc.price_per_day desc;
end;

